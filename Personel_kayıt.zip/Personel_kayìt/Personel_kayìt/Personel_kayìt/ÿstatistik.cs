﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;//Sql den veri çekmek için kullanılır . 

namespace Personel_kayıt
{
    public partial class İstatistik : Form
    {
        public İstatistik()
        {
            InitializeComponent();
        }
        SqlConnection bağlanti = new SqlConnection("Data Source=LAPTOP-QKT6284C;Initial Catalog=PersonelVeriTabani;Integrated Security=True");
        private void İstatistik_Load(object sender, EventArgs e)
        {
            //Toplam Personel Sayısı :
            bağlanti.Open();
            SqlCommand komut1 = new SqlCommand("Select Count(*) From Tbl_Personel ",bağlanti);
            SqlDataReader dr1=komut1.ExecuteReader();//sqldatareader = Okuyucu . ExecuteReader=Select için okyucuyu çalıştır.
            while(dr1.Read())//d1 komutunu sırayla okuyana kadar.       
            {
                label2.Text = dr1[0].ToString();                
            }
            bağlanti.Close();
            //Evli Personel sayısı
            bağlanti.Open();
            SqlCommand komut2 = new SqlCommand("Select Count(*) From Tbl_Personel where PerDurum=1", bağlanti);
            SqlDataReader dr2=komut2.ExecuteReader();
            while(dr2.Read())
            {
                label4.Text = dr2[0].ToString();
            }
            bağlanti.Close();
            //Bekar Personel Sayısı
            bağlanti.Open();
            //NOT:sqlcommand kısmında veri tabanı komutumuzu yazdıktan sonra bağlantı kısmını unutmuyoruz kesinlikle!
            SqlCommand komut3 = new SqlCommand("Select Count(*) From Tbl_Personel Where PerDurum=0", bağlanti);
            SqlDataReader dr3=komut3.ExecuteReader();
            while (dr3.Read())
            {
                label6.Text = dr3[0].ToString();    
            }
                
                bağlanti.Close();
            //Personel Şehir Sayısı  
            bağlanti.Open();
            SqlCommand komut4 = new SqlCommand("Select Count(distinct(PerSehir)) From Tbl_Personel",bağlanti);
            SqlDataReader dr4=komut4.ExecuteReader();
            while (dr4.Read())
            {
               label8.Text = dr4[0].ToString();
            }
            bağlanti.Close();
            //Personel Toplam Maaşi
            bağlanti.Open();
            SqlCommand komut5 = new SqlCommand("Select Sum(Permaas) From Tbl_Personel", bağlanti);
            SqlDataReader dr5=komut5.ExecuteReader();
            while (dr5.Read())
            { 
            label9.Text = dr5[0].ToString();
            }
            bağlanti.Close();
            //Ortalama maas
            bağlanti.Open();
            SqlCommand komut6 = new SqlCommand("Select Avg(PerMaas) From Tbl_Personel",bağlanti);
            SqlDataReader dr6=komut6.ExecuteReader();
            while (dr6.Read())
            {
                label11.Text = dr6[0].ToString();
            }
            bağlanti.Close();
        }
    }
}
